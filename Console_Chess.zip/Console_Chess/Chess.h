#include "Variables.h"
#include "Structers.h"
#include "Initializations.h"
#include "Prints.h"
#include "BasicRules.h"
#include "CheckPin.h"
#include "Pawn.h"
#include "Bishop.h"
#include "Knight.h"
#include "Rook.h"
#include "Queen.h"
#include "King.h"
#include "Stalemate.h"
#include "Checkmate.h" 
#include "TakeInput.h"
void chess() {
	InitializeAll();
	welcomenote();
	PrintBoard();
	TakeInput();
}