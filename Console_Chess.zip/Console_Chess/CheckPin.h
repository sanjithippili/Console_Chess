void tempsetDefault() {
	/*CB[x2][y2].Player = 0;
	CB[x2][y2].PieceName = ' ';
	CB[x2][y2].PieceCount = 0;
	CB[x2][y2].PieceSource.h = 0;
	CB[x2][y2].PieceSource.v = 0;
	CB[x2][y2].PieceDestination.h = 0;
	CB[x2][y2].PieceDestination.v = 0;*/

	CB[tempx1][tempy1].Player = temp2.Player;
	CB[tempx1][tempy1].PieceName = temp2.PieceName;
	CB[tempx1][tempy1].PieceCount = temp2.PieceCount;
	CB[tempx1][tempy1].PieceSource.h = temp2.PieceSource.h;
	CB[tempx1][tempy1].PieceSource.v = temp2.PieceSource.v;
	CB[tempx1][tempy1].PieceDestination.h = temp2.PieceDestination.h;
	CB[tempx1][tempy1].PieceDestination.v = temp2.PieceDestination.v;

	CB[tempx2][tempy2].Player = temp1.Player;
	CB[tempx2][tempy2].PieceName = temp1.PieceName;
	CB[tempx2][tempy2].PieceCount = temp1.PieceCount;
	CB[tempx2][tempy2].PieceSource.h = temp1.PieceSource.h;
	CB[tempx2][tempy2].PieceSource.v = temp1.PieceSource.v;
	CB[tempx2][tempy2].PieceDestination.h = temp1.PieceDestination.h;
	CB[tempx2][tempy2].PieceDestination.v = temp1.PieceDestination.v;
}
void pinmove() {
	CB[tempx2][tempy2].Player = CB[tempx1][tempy1].Player;
	CB[tempx2][tempy2].PieceName = CB[tempx1][tempy1].PieceName;
	CB[tempx2][tempy2].PieceCount = CB[tempx1][tempy1].PieceCount;
	CB[tempx2][tempy2].PieceSource.h = CB[tempx1][tempy1].PieceDestination.h;
	CB[tempx2][tempy2].PieceSource.v = CB[tempx1][tempy1].PieceDestination.v;
	CB[tempx2][tempy2].PieceDestination.h = tempx2;
	CB[tempx2][tempy2].PieceDestination.v = tempy2;
}



void setDefaultPin(int x1, int y1) {
	CB[x1][y1].Player = 0;
	CB[x1][y1].PieceName = ' ';
	CB[x1][y1].PieceCount = 0;
	CB[x1][y1].PieceSource.h = 0;
	CB[x1][y1].PieceSource.v = 0;
	CB[x1][y1].PieceDestination.h = 0;
	CB[x1][y1].PieceDestination.v = 0;
}

bool pin(int pin_flag, int check) {
	if (pin_flag && check) {
		if (PlayerTurn == 2) {
			kx = Status[1][4].PiecePosition.h;
			ky = Status[1][4].PiecePosition.v;
		}
		else {
			kx = Status[0][4].PiecePosition.h;
			ky = Status[0][4].PiecePosition.v;
		}
	}
	else {
		if (PlayerTurn == 2) {
			kx = Status[0][4].PiecePosition.h;
			ky = Status[0][4].PiecePosition.v;
		}
		else {
			kx = Status[1][4].PiecePosition.h;
			ky = Status[1][4].PiecePosition.v;
		}
	}
	// store values of x2 y2 in temporary variable.
	// destination
	temp1.Player = CB[tempx2][tempy2].Player;
	temp1.PieceName = CB[tempx2][tempy2].PieceName;
	temp1.PieceCount = CB[tempx2][tempy2].PieceCount;
	temp1.PieceSource.h = CB[tempx2][tempy2].PieceSource.h;
	temp1.PieceSource.v = CB[tempx2][tempy2].PieceSource.v;
	temp1.PieceDestination.h = CB[tempx2][tempy2].PieceDestination.h;
	temp1.PieceDestination.v = CB[tempx2][tempy2].PieceDestination.v;
	// source
	temp2.Player = CB[tempx1][tempy1].Player;
	temp2.PieceName = CB[tempx1][tempy1].PieceName;
	temp2.PieceCount = CB[tempx1][tempy1].PieceCount;
	temp2.PieceSource.h = CB[tempx1][tempy1].PieceSource.h;
	temp2.PieceSource.v = CB[tempx1][tempy1].PieceSource.v;
	temp2.PieceDestination.h = CB[tempx1][tempy1].PieceDestination.h;
	temp2.PieceDestination.v = CB[tempx1][tempy1].PieceDestination.v;

	pinmove();
	setDefaultPin(tempx1, tempy1);

	//PAWN
	if (CB[kx][ky].Player == 2) {
		if (CB[kx + 1][ky - 1].Player != CB[kx][ky].Player && CB[kx + 1][ky - 1].PieceName == 'P') {
			ck = 1;
			tempsetDefault();
			return false;
		}
		if (CB[kx + 1][ky + 1].Player != CB[kx][ky].Player && CB[kx + 1][ky + 1].PieceName == 'P') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (CB[kx][ky].Player == 1) {
		if (CB[kx - 1][ky - 1].Player != CB[kx][ky].Player && CB[kx - 1][ky - 1].PieceName == 'P') {
			ck = 1;
			tempsetDefault();
			return false;
		}
		if (CB[kx - 1][ky + 1].Player != CB[kx][ky].Player && CB[kx - 1][ky + 1].PieceName == 'P') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}

	//PLUS
	//Left direction
	for (int i = ky - 1; i >= 0; i--) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kx][ky].Player) {
			if (kx == x1 && i == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[kx][i].Player != CB[kx][ky].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Right direction 
	for (int i = ky + 1; i < 8; i++) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kx][ky].Player) {
			if (kx == x1 && i == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[kx][i].Player != CB[kx][ky].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down direction 
	for (int i = kx + 1; i < 8; i++) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kx][ky].Player) {
			if (i == x1 && ky == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][ky].Player != CB[kx][ky].Player) {
			if (CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//UP direction 
	for (int i = kx - 1; i >= 0; i--) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kx][ky].Player) {
			if (i == x1 && ky == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][ky].Player != CB[kx][ky].Player) {
			if (CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//DIAGONAL
	//UP Left
	for (int i = kx - 1, j = ky - 1; i >= 0 && j >= 0; i--, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			if (i == x1 && j == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down Right
	for (int i = kx + 1, j = ky + 1; i < 8 && j < 8; i++, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			if (i == x1 && j == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Up Right
	for (int i = kx - 1, j = ky + 1; i >= 0 && j < 8; i--, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			if (i == x1 && j == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Down Left
	for (int i = kx + 1, j = ky - 1; i < 8 && j >= 0; i++, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			if (i == x1 && j == y1) {
				continue;
			}
			else {
				ck = 0;
				break;
			}
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				tempsetDefault();
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//L Direction
	if (isWithInIndex(kx - 1, ky - 2)) {
		if (CB[kx - 1][ky - 2].Player == CB[kx][ky].Player || CB[kx - 1][ky - 2].Player == 0) ck = 0;
		if (CB[kx - 1][ky - 2].Player != CB[kx][ky].Player && CB[kx - 1][ky - 2].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx - 1, ky + 2)) {
		if (CB[kx - 1][ky + 2].Player == CB[kx][ky].Player || CB[kx - 1][ky + 2].Player == 0) ck = 0;
		if (CB[kx - 1][ky + 2].Player != CB[kx][ky].Player && CB[kx - 1][ky + 2].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky - 2)) {
		if (CB[kx + 1][ky - 2].Player == CB[kx][ky].Player || CB[kx + 1][ky - 2].Player == 0) ck = 0;
		if (CB[kx + 1][ky - 2].Player != CB[kx][ky].Player && CB[kx + 1][ky - 2].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky + 2)) {
		if (CB[kx + 1][ky + 2].Player == CB[kx][ky].Player || CB[kx + 1][ky + 2].Player == 0) ck = 0;
		if (CB[kx + 1][ky + 2].Player != CB[kx][ky].Player && CB[kx + 1][ky + 2].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky - 1)) {
		if (CB[kx - 2][ky - 1].Player == CB[kx][ky].Player || CB[kx - 2][ky - 1].Player == 0) ck = 0;
		if (CB[kx - 2][ky - 1].Player != CB[kx][ky].Player && CB[kx - 2][ky - 1].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky + 1)) {
		if (CB[kx - 2][ky + 1].Player == CB[kx][ky].Player || CB[kx - 2][ky + 1].Player == 0) ck = 0;
		if (CB[kx - 2][ky + 1].Player != CB[kx][ky].Player && CB[kx - 2][ky + 1].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky - 1)) {
		if (CB[kx + 2][ky - 1].Player == CB[kx][ky].Player || CB[kx + 2][ky - 1].Player == 0) ck = 0;
		if (CB[kx + 2][ky - 1].Player != CB[kx][ky].Player && CB[kx + 2][ky - 1].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky + 1)) {
		if (CB[kx + 2][ky + 1].Player == CB[kx][ky].Player || CB[kx + 2][ky + 1].Player == 0) ck = 0;
		if (CB[kx + 2][ky + 1].Player != CB[kx][ky].Player && CB[kx + 2][ky + 1].PieceName == 'N') {
			ck = 1;
			tempsetDefault();
			return false;
		}
	}
	tempsetDefault();
	return true;
}


bool CAD() {
	if (PlayerTurn == 2) {
		kx = Status[1][4].PiecePosition.h;
		ky = Status[1][4].PiecePosition.v;
	}
	else {
		kx = Status[0][4].PiecePosition.h;
		ky = Status[0][4].PiecePosition.v;
	}
	//FOR PAWN
	if (PlayerTurn == 2) {
		if (isWithInIndex(kx - 1, ky - 1)) {
			if (CB[kx][ky].Player != CB[kx - 1][ky - 1].Player && CB[kx - 1][ky - 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
		if (isWithInIndex(kx - 1, ky + 1)) {
			if (CB[kx][ky].Player != CB[kx - 1][ky + 1].Player && CB[kx - 1][ky + 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
	}
	if (PlayerTurn == 1) {
		if (isWithInIndex(kx + 1, ky - 1)) {
			if (CB[kx][ky].Player != CB[kx + 1][ky - 1].Player && CB[kx + 1][ky - 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
		if (isWithInIndex(kx + 1, ky + 1)) {
			if (CB[kx][ky].Player != CB[kx + 1][ky + 1].Player && CB[kx + 1][ky + 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
	}

	//PLUS
	//Left direction 
	for (int i = ky - 1; i >= 0; i--) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[kx][i].Player != CB[kx][ky].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Right direction 
	for (int i = ky + 1; i < 8; i++) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[kx][i].Player != CB[kx][ky].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Down direction 
	for (int i = kx + 1; i < 8; i++) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][ky].Player != CB[kx][ky].Player) {
			if (CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Up direction 
	for (int i = kx - 1; i >= 0; i--) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][ky].Player != CB[kx][ky].Player) {
			if (CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//DIAGONAL
	//UP Left
	for (int i = kx - 1, j = ky - 1; i >= 0 && j >= 0; i--, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down Right
	for (int i = kx + 1, j = ky + 1; i < 8 && j < 8; i++, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Up Right
	for (int i = kx - 1, j = ky + 1; i >= 0 && j < 8; i--, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down Left
	for (int i = kx + 1, j = ky - 1; i < 8 && j >= 0; i++, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kx][ky].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kx][ky].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//L Direction
	if (isWithInIndex(kx - 1, ky - 2)) {
		if (CB[kx - 1][ky - 2].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx - 1][ky - 2].Player != CB[kx][ky].Player && CB[kx - 1][ky - 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 1, ky + 2)) {
		if (CB[kx - 1][ky + 2].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx - 1][ky + 2].Player != CB[kx][ky].Player && CB[kx - 1][ky + 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky - 2)) {
		if (CB[kx + 1][ky - 2].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx + 1][ky - 2].Player != CB[kx][ky].Player && CB[kx + 1][ky - 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky + 2)) {
		if (CB[kx + 1][ky + 2].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx + 1][ky + 2].Player != CB[kx][ky].Player && CB[kx + 1][ky + 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky - 1)) {
		if (CB[kx - 2][ky - 1].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx - 2][ky - 1].Player != CB[kx][ky].Player && CB[kx - 2][ky - 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky + 1)) {
		if (CB[kx - 2][ky + 1].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx - 2][ky + 1].Player != CB[kx][ky].Player && CB[kx - 2][ky + 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky - 1)) {
		if (CB[kx + 2][ky - 1].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx + 2][ky - 1].Player != CB[kx][ky].Player && CB[kx + 2][ky - 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky + 1)) {
		if (CB[kx + 2][ky + 1].Player == CB[kx][ky].Player) ck = 0;
		if (CB[kx + 2][ky + 1].Player != CB[kx][ky].Player && CB[kx + 2][ky + 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	return true;
}