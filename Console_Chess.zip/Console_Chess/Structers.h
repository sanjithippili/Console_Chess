
// for piece position coordinate using (i,j) indices in chess board
struct Position {
	int h;
	int v;
};

// Chess board cells Structure
struct ChessBoard {
	int Player;
	char PieceName;
	int PieceCount;
	struct Position PieceSource;
	struct Position PieceDestination;
} CB[8][8], temp, temp1, temp2;

// Individual chess piece status
struct PieceStatus {
	int Player;
	bool isAlive;
	char PieceName;
	int PieceCount;
	struct Position PiecePosition;
} Status[2][16];