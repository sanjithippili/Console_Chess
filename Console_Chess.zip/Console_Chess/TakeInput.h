void CP() {
	// Change Player
	PlayerTurn = (PlayerTurn == 1) ? 2 : 1;
}
void IM() {
	// Invalid Move
	printf("\nInvalid move...!\n");
}

bool isInputValid(char str[]) {
	int n = strlen(str);
	if (n != 4 || !isWithInBoundary(str[0], str[1]) || !isWithInBoundary(str[2], str[3]))
		return false;

	y1 = str[0] - 'A';
	x1 = '8' - str[1];
	y2 = str[2] - 'A';
	x2 = '8' - str[3];
	tempx1 = x1;
	tempy1 = y1;
	tempx2 = x2;
	tempy2 = y2;

	//printf("\n x1=%d  , y1=%d , x2=%d ,y2=%d \n", x1, y1, x2, y2);
	if (x1 == x2 && y1 == y2)
		return false;
	return true;
}


void TakeInput() {
	while (true) {

		input_color = (PlayerTurn == 1) ? 32 : 91;
		printf("\n\n\n\n\x1b[%dmNow its player %d turn : \x1b[0m", input_color, PlayerTurn);
		scanf_s(" %s", ip, sizeof(ip));
		if (ip[0] == '#') {
			instrunctions();
			continue;
		}
		
		if (isInputValid(ip)) {
			if (CB[x1][y1].Player != PlayerTurn || CB[x2][y2].Player == PlayerTurn) {
				IM();
				continue;
			}
			switch (CB[x1][y1].PieceName) {
				if (stale) stale++;
			case 'P':if (CheckPawn(0, 0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					else IM();	break;
			case 'B':if (CheckBishop(0, 0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					else IM();	break;
			case 'N':if (CheckKnight(0, 0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					else IM();	break;
			case 'R':if (CheckRook(0, 0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					else IM();	break;
			case 'Q':if (CheckQueen(0, 0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					else IM();	break;
			case 'K':if (CheckKing(0, x1, y1, x2, y2)) {
				PrintAll();
				if (!CAD()) {
					if (checkmate()) {
						printf("\n\x1b[33mCheckMate..!\x1b[0m\n");
						printf("\n\x1b[%dmPlayer - %d won the game..!\x1b[0m", (PlayerTurn == 1) ? 32 : 91, PlayerTurn);
						getch();
						return;
					}
					printf("\n\x1b[33mCheck..!\x1b[0m\n");
					CP();
					continue;
				}
				else {
					if (isStaleMate()) {
						stale = 1;
						printf("\n\x1b[33mStaleMate..!\x1b[0m\n");
						getch();
						return;
						CP();
						continue;
					}
				}
				CP();
			}
					break;
			}
		}
		else {
			printf("\nInvalid, Please follow the correct format mentioned bellow !!");
			PrintNotation();
		}
	}
}