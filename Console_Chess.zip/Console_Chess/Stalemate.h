bool isRookMovable(int rx, int ry) {
	if ((isWithInIndex(rx, ry - 1) && CheckRook(1, 1, rx, ry, rx, ry - 1))) return true;
	if ((isWithInIndex(rx, ry + 1) && CheckRook(1, 1, rx, ry, rx, ry + 1))) return true;
	if ((isWithInIndex(rx - 1, ry) && CheckRook(1, 1, rx, ry, rx - 1, ry))) return true;
	if ((isWithInIndex(rx + 1, ry) && CheckRook(1, 1, rx, ry, rx + 1, ry))) return true;
	return false;
}
bool isKnightMovable(int nx, int ny) {
	if ((isWithInIndex(nx - 1, ny - 2) && CheckKnight(1, 1, nx, ny, nx - 1, ny - 2))) return true;
	if ((isWithInIndex(nx - 1, ny + 2) && CheckKnight(1, 1, nx, ny, nx - 1, ny + 2))) return true;
	if ((isWithInIndex(nx + 1, ny - 2) && CheckKnight(1, 1, nx, ny, nx + 1, ny - 2))) return true;
	if ((isWithInIndex(nx + 1, ny + 2) && CheckKnight(1, 1, nx, ny, nx + 1, ny + 2))) return true;
	if ((isWithInIndex(nx - 2, ny - 1) && CheckKnight(1, 1, nx, ny, nx - 2, ny - 1))) return true;
	if ((isWithInIndex(nx - 2, ny + 1) && CheckKnight(1, 1, nx, ny, nx - 2, ny + 1))) return true;
	if ((isWithInIndex(nx + 2, ny - 1) && CheckKnight(1, 1, nx, ny, nx + 2, ny - 1))) return true;
	if ((isWithInIndex(nx + 2, ny + 1) && CheckKnight(1, 1, nx, ny, nx + 2, ny + 1))) return true;
	return false;
}
bool isBishopMovable(int bx, int by) {
	if ((isWithInIndex(bx - 1, by - 1) && CheckBishop(1, 1, bx, by, bx - 1, by - 1))) return true;
	if ((isWithInIndex(bx + 1, by + 1) && CheckBishop(1, 1, bx, by, bx + 1, by + 1))) return true;
	if ((isWithInIndex(bx - 1, by + 1) && CheckBishop(1, 1, bx, by, bx - 1, by + 1))) return true;
	if ((isWithInIndex(bx + 1, by - 1) && CheckBishop(1, 1, bx, by, bx + 1, by - 1))) return true;
	return false;
}
bool isQueenMovable(int qx, int qy) {
	if (isBishopMovable(qx, qy)) {
		return true;
	}
	if (isRookMovable(qx, qy)) {
		return true;
	}
	return false;
}
bool isKingMovable(int kx, int ky) {
	if ((isWithInIndex(kx - 1, ky - 1) && CB[kx][ky].Player != CB[kx - 1][ky - 1].Player && CheckKing(1, kx, ky, kx - 1, ky - 1))) return true;
	if ((isWithInIndex(kx - 1, ky) && CB[kx][ky].Player != CB[kx - 1][ky].Player && CheckKing(1, kx, ky, kx - 1, ky))) return true;
	if ((isWithInIndex(kx - 1, ky + 1) && CB[kx][ky].Player != CB[kx - 1][ky + 1].Player && CheckKing(1, kx, ky, kx - 1, ky + 1))) return true;
	if ((isWithInIndex(kx, ky - 1) && CB[kx][ky].Player != CB[kx][ky - 1].Player && CheckKing(1, kx, ky, kx, ky - 1))) return true;
	if ((isWithInIndex(kx, ky + 1) && CB[kx][ky].Player != CB[kx][ky + 1].Player && CheckKing(1, kx, ky, kx, ky + 1))) return true;
	if ((isWithInIndex(kx + 1, ky - 1) && CB[kx][ky].Player != CB[kx + 1][ky - 1].Player && CheckKing(1, kx, ky, kx + 1, ky - 1))) return true;
	if ((isWithInIndex(kx + 1, ky) && CB[kx][ky].Player != CB[kx + 1][ky].Player && CheckKing(1, kx, ky, kx + 1, ky))) return true;
	if ((isWithInIndex(kx + 1, ky + 1) && CB[kx][ky].Player != CB[kx + 1][ky + 1].Player && CheckKing(1, kx, ky, kx + 1, ky + 1))) return true;
	return false;
}
bool isPawnMovable(int px, int py) {
	tempx2 = px - 1;
	tempy2 = py;
	if ((isWithInIndex(px - 1, py) && CheckPawn(1, 1, px, py, px - 1, py))) return true;
	tempx2 = px - 2;
	tempy2 = py;
	if ((isWithInIndex(px - 2, py) && CheckPawn(1, 1, px, py, px - 2, py))) return true;
	tempx2 = px + 1;
	tempy2 = py;
	if ((isWithInIndex(px + 1, py) && CheckPawn(1, 1, px, py, px + 1, py))) return true;
	tempx2 = px + 2;
	tempy2 = py;
	if ((isWithInIndex(px + 2, py) && CheckPawn(1, 1, px, py, px + 2, py))) return true;
	tempx2 = px - 1;
	tempy2 = py - 1;
	if ((isWithInIndex(px - 1, py - 1) && CheckPawn(1, 1, px, py, px - 1, py - 1))) return true;
	tempx2 = px - 1;
	tempy2 = py + 1;
	if ((isWithInIndex(px - 1, py + 1) && CheckPawn(1, 1, px, py, px - 1, py + 1))) return true;
	tempx2 = px + 1;
	tempy2 = py - 1;
	if ((isWithInIndex(px + 1, py - 1) && CheckPawn(1, 1, px, py, px + 1, py - 1))) return true;
	tempx2 = px + 1;
	tempy2 = py + 1;
	if ((isWithInIndex(px + 1, py + 1) && CheckPawn(1, 1, px, py, px + 1, py + 1))) return true;
	return false;
}
bool isStaleMate() {
	int ind = (PlayerTurn == 1) ? 0 : 1;
	for (int i = 0; i < 16; i++) {
		if (Status[ind][i].isAlive) {
			switch (Status[ind][i].PieceName) {
			case 'R': if (isRookMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			case 'N': if (isKnightMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			case 'B': if (isBishopMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			case 'Q': if (isQueenMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			case 'K': if (isKingMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			case 'P': if (isPawnMovable(Status[ind][i].PiecePosition.h, Status[ind][i].PiecePosition.v)) {
				return false;
			}
					break;
			}
		}
	}
	return true;
}