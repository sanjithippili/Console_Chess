bool isWithInIndex(int x, int y) {
	if (x < 0 || x>7 || y < 0 || y>7)
		return false;
	return true;
}


// to check input piece name is valid or not
bool isValidPieceName(char ch) {
	for (int i = 0; i < strlen(PieceNames); i++)
		if (ch == PieceNames[i])
			return true;
	return false;
}

// to check whether piece is with in boundary or not
bool isWithInBoundary(char a, char b) {
	if (a < 'A' || a > 'H') return false;
	if (b < '1' || b > '8') return false;
	return true;
}

void pinkill() {
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == temp1.PieceName && Status[index][i].PieceCount == temp1.PieceCount) {
			Status[index][i].isAlive = false;
			Status[index][i].PiecePosition.h = -1;
			Status[index][i].PiecePosition.v = -1;
		}
	}
}

void setDefault() {
	CB[x1][y1].Player = 0;
	CB[x1][y1].PieceName = ' ';
	CB[x1][y1].PieceCount = 0;
	CB[x1][y1].PieceSource.h = 0;
	CB[x1][y1].PieceSource.v = 0;
	CB[x1][y1].PieceDestination.h = 0;
	CB[x1][y1].PieceDestination.v = 0;
}

void UpdateStatus() {
	(PlayerTurn == 1) ? (index = 1) : (index = 0);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == CB[x2][y2].PieceName && Status[index][i].PieceCount == CB[x2][y2].PieceCount) {
			Status[index][i].PiecePosition.h = x2;
			Status[index][i].PiecePosition.v = y2;
		}
	}
}

void usemove() {
	CB[x2][y2].Player = CB[x1][y1].Player;
	CB[x2][y2].PieceName = CB[x1][y1].PieceName;
	CB[x2][y2].PieceCount = CB[x1][y1].PieceCount;
	CB[x2][y2].PieceSource.h = CB[x1][y1].PieceDestination.h;
	CB[x2][y2].PieceSource.v = CB[x1][y1].PieceDestination.v;
	CB[x2][y2].PieceDestination.h = x2;
	CB[x2][y2].PieceDestination.v = y2;
}
void updatetemp() {
	/*temp1.Player = temp.Player;
	temp1.PieceName = temp.PieceName;
	temp1.PieceCount = temp.PieceCount;
	temp1.PieceSource.h = temp.PieceSource.h;
	temp1.PieceSource.v = temp.PieceSource.v;
	temp1.PieceDestination.h = temp.PieceDestination.h;
	temp1.PieceDestination.v = temp.PieceDestination.v;*/

	temp.Player = CB[x2][y2].Player;
	temp.PieceName = CB[x2][y2].PieceName;
	temp.PieceCount = CB[x2][y2].PieceCount;
	temp.PieceSource.h = CB[x2][y2].PieceSource.h;
	temp.PieceSource.v = CB[x2][y2].PieceSource.v;
	temp.PieceDestination.h = CB[x2][y2].PieceDestination.h;
	temp.PieceDestination.v = CB[x2][y2].PieceDestination.v;
}
void move() {
	usemove();
	updatetemp();
	UpdateStatus();
	setDefault();
}

void castlingMove(char PieceName, int x1, int y1, int x2, int y2) {
	//usemove() replace function
	CB[x2][y2].Player = CB[x1][y1].Player;
	CB[x2][y2].PieceName = CB[x1][y1].PieceName;
	CB[x2][y2].PieceCount = CB[x1][y1].PieceCount;
	CB[x2][y2].PieceSource.h = CB[x1][y1].PieceDestination.h;
	CB[x2][y2].PieceSource.v = CB[x1][y1].PieceDestination.v;
	CB[x2][y2].PieceDestination.h = x2;
	CB[x2][y2].PieceDestination.v = y2;
	//updatetemp();
	temp.Player = CB[x2][y2].Player;
	temp.PieceName = CB[x2][y2].PieceName;
	temp.PieceCount = CB[x2][y2].PieceCount;
	temp.PieceSource.h = CB[x2][y2].PieceSource.h;
	temp.PieceSource.v = CB[x2][y2].PieceSource.v;
	temp.PieceDestination.h = CB[x2][y2].PieceDestination.h;
	temp.PieceDestination.v = CB[x2][y2].PieceDestination.v;
	//UpdateStatus();
	(PlayerTurn == 1) ? (index = 1) : (index = 0);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == PieceName && Status[index][i].PieceCount == CB[x2][y2].PieceCount) {
			Status[index][i].PiecePosition.h = x2;
			Status[index][i].PiecePosition.v = y2;
		}
	}
	//setDefault();
	CB[x1][y1].Player = 0;
	CB[x1][y1].PieceName = ' ';
	CB[x1][y1].PieceCount = 0;
	CB[x1][y1].PieceSource.h = 0;
	CB[x1][y1].PieceSource.v = 0;
	CB[x1][y1].PieceDestination.h = 0;
	CB[x1][y1].PieceDestination.v = 0;
}



void kill() {
	// to update dead piece status to make it was dead
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == CB[x2][y2].PieceName && Status[index][i].PieceCount == CB[x2][y2].PieceCount) {
			Status[index][i].isAlive = false;
			Status[index][i].PiecePosition.h = -1;
			Status[index][i].PiecePosition.v = -1;
		}
	}
	(PlayerTurn == 1) ? (index = 1) : (index = 0);
	// TO update the killer piece position to destion place
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == CB[x1][y1].PieceName && Status[index][i].PieceCount == CB[x1][y1].PieceCount) {
			Status[index][i].PiecePosition.h = x2;
			Status[index][i].PiecePosition.v = y2;
		}
	}
	usemove();
	updatetemp();
	setDefault();
}

void EnpassantKill(int ind) {
	// to update dead piece status to make it was dead
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == CB[ind][y2].PieceName && Status[index][i].PieceCount == CB[ind][y2].PieceCount) {
			Status[index][i].isAlive = false;
			Status[index][i].PiecePosition.h = -1;
			Status[index][i].PiecePosition.v = -1;
			break;
		}
	}
	(PlayerTurn == 1) ? (index = 1) : (index = 0);
	// TO update the killer piece position to destination place
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName == CB[x1][y1].PieceName && Status[index][i].PieceCount == CB[x1][y1].PieceCount) {
			Status[index][i].PiecePosition.h = x2;
			Status[index][i].PiecePosition.v = y2;
			break;
		}
	}
	usemove();
	updatetemp();
	setDefault();
	CB[ind][y2].Player = 0;
	CB[ind][y2].PieceName = ' ';
	CB[ind][y2].PieceCount = 0;
	CB[ind][y2].PieceSource.h = 0;
	CB[ind][y2].PieceSource.v = 0;
	CB[ind][y2].PieceDestination.h = 0;
	CB[ind][y2].PieceDestination.v = 0;
	//PrintBoard();
}