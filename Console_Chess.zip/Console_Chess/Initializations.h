
//Initialization of chess board with default values
void InitializeChessBoard() {
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			CB[i][j].Player = 0;
			CB[i][j].PieceName = ' ';
			CB[i][j].PieceCount = 0;
			CB[i][j].PieceSource.h = 0;
			CB[i][j].PieceSource.v = 0;
			CB[i][j].PieceDestination.h = 0;
			CB[i][j].PieceDestination.v = 0;
		}
	}

	for (int i = 0; i < 8; i++) {
		if (i > 1 && i < 6) continue;
		for (int j = 0; j < 8; j++) {
			CB[i][j].Player = (i == 0 || i == 1) ? 2 : (i == 6 || i == 7) ? 1 : 0;
			if (i == 0 || i == 7) {
				if (j == 0 || j == 7)
					CB[i][j].PieceName = 'R';
				else if (j == 1 || j == 6)
					CB[i][j].PieceName = 'N';
				else if (j == 2 || j == 5)
					CB[i][j].PieceName = 'B';
				else if (j == 3)
					CB[i][j].PieceName = 'Q';
				else if (j == 4)
					CB[i][j].PieceName = 'K';

				if (j > 4)
					CB[i][j].PieceCount = CB[i][j - 5].PieceCount + 1;
				else CB[i][j].PieceCount = 1;
			}
			else {
				CB[i][j].PieceName = 'P';
				if (j == 0)
					CB[i][j].PieceCount = 1;
				else
					CB[i][j].PieceCount = CB[i][j - 1].PieceCount + 1;
			}

			CB[i][j].PieceSource.h = i;
			CB[i][j].PieceSource.v = j;
			CB[i][j].PieceDestination.h = i;
			CB[i][j].PieceDestination.v = j;
		}
	}
}


//to Initialize the piece count which are alive
void InitializePieceCount() {
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 5; j++) {
			switch (j) {
			case 0:
			case 1:
			case 2:
				PieceCount[i][j] = 2;
				break;
			case 3:
				PieceCount[i][j] = 1;
				break;
			case 4:
				PieceCount[i][j] = 8;
				break;
			}
		}
	}
}

//Initializing piece status [2]x[16]
void InitializePieceStatus() {
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 16; j++) {
			if (i == 0) {
				if (j < 8) {
					Status[i][j].Player = CB[i][j].Player;
					Status[i][j].isAlive = true;
					Status[i][j].PieceName = CB[i][j].PieceName;
					Status[i][j].PieceCount = CB[i][j].PieceCount;
					Status[i][j].PiecePosition.h = CB[i][j].PieceSource.h;
					Status[i][j].PiecePosition.v = CB[i][j].PieceSource.v;

				}
				else {
					Status[i][j].Player = CB[i + 1][j - 8].Player;
					Status[i][j].isAlive = true;
					Status[i][j].PieceName = CB[i + 1][j - 8].PieceName;
					Status[i][j].PieceCount = CB[i + 1][j - 8].PieceCount;
					Status[i][j].PiecePosition.h = CB[i + 1][j - 8].PieceSource.h;
					Status[i][j].PiecePosition.v = CB[i + 1][j - 8].PieceSource.v;
				}
			}
			else {
				if (j < 8) {
					Status[i][j].Player = CB[i + 6][j].Player;
					Status[i][j].isAlive = true;
					Status[i][j].PieceName = CB[i + 6][j].PieceName;
					Status[i][j].PieceCount = CB[i + 6][j].PieceCount;
					Status[i][j].PiecePosition.h = CB[i + 6][j].PieceSource.h;
					Status[i][j].PiecePosition.v = CB[i + 6][j].PieceSource.v;

				}
				else {
					Status[i][j].Player = CB[i + 5][j - 8].Player;
					Status[i][j].isAlive = true;
					Status[i][j].PieceName = CB[i + 5][j - 8].PieceName;
					Status[i][j].PieceCount = CB[i + 5][j - 8].PieceCount;
					Status[i][j].PiecePosition.h = CB[i + 5][j - 8].PieceSource.h;
					Status[i][j].PiecePosition.v = CB[i + 5][j - 8].PieceSource.v;
				}
			}
		}
	}
}

void InitializeAll() {
	InitializeChessBoard();
	InitializePieceCount();
	InitializePieceStatus();
}