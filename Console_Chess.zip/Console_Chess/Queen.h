bool CheckQueen(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (isDiagonal(x1, y1, x2, y2)) return CheckBishop(check, pin_flag, x1, y1, x2, y2);
	else return CheckRook(check, pin_flag, x1, y1, x2, y2);
}