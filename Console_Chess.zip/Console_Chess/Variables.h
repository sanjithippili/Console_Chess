int PieceCount[2][5];

char PieceNames[6] = "RNBQPK";

int x1, y1, x2, y2;

char ip[30];

int PlayerTurn = 1;

int AliveIndex;

int PromotionPiece;

int index;

int color1, color2;

int player_color;

int color_code;

int input_color;

int castlingIndex;

int ck = -1;

int cs[16] = { -1 };

int ck_flag = -1;

int kx, ky;

int stale = 1;

int tempx1, tempy1, tempx2, tempy2;

int pin_flag;
 
char start;