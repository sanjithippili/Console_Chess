
bool isPlusCheckMate(int a, int b, int kx, int ky) {
	if (CB[a][b].Player != CB[kx][ky].Player && (CB[a][b].PieceName == 'Q' || CB[a][b].PieceName == 'R'))
		return true;
	return false;
}
bool isIntoCheckMate(int a, int b, int kx, int ky) {
	if (CB[a][b].Player != CB[kx][ky].Player && (CB[a][b].PieceName == 'Q' || CB[a][b].PieceName == 'B'))
		return true;
	return false;
}
bool isLShapeCheckMate(int a, int b, int kx, int ky) {
	if (CB[a][b].Player != 0) {
		if (CB[a][b].Player != CB[kx][ky].Player && CB[a][b].PieceName == 'N')
			return true;
	}
	return false;
}

bool isCheckMateSafe(int x, int y, int a, int b) {
	int i, j;

	int c = x, d = y;

	if (CB[c - 1][d - 1].Player != CB[a][b].Player && CB[c - 1][d - 1].PieceName == 'K')
		return false;
	if (CB[c - 1][d].Player != CB[a][b].Player && CB[c - 1][d].PieceName == 'K')
		return false;
	if (CB[c - 1][d + 1].Player != CB[a][b].Player && CB[c - 1][d + 1].PieceName == 'K')
		return false;
	if (CB[c][d - 1].Player != CB[a][b].Player && CB[c][d - 1].PieceName == 'K')
		return false;
	if (CB[c][d + 1].Player != CB[a][b].Player && CB[c][d + 1].PieceName == 'K')
		return false;
	if (CB[c + 1][d - 1].Player != CB[a][b].Player && CB[c + 1][d - 1].PieceName == 'K')
		return false;
	if (CB[c + 1][d].Player != CB[a][b].Player && CB[c + 1][d].PieceName == 'K')
		return false;
	if (CB[c + 1][d + 1].Player != CB[a][b].Player && CB[c + 1][d + 1].PieceName == 'K')
		return false;


	if (PlayerTurn == 1) {
		i = x - 1;
		j = y - 1;
		if (isWithInIndex(i, j)) {
			if (CB[i][j].Player == 2 && CB[i][j].PieceName == 'P')
				return false;
		}
		j = y + 1;
		if (isWithInIndex(i, j)) {
			if (CB[i][j].Player == 2 && CB[i][j].PieceName == 'P')
				return false;
		}
	}
	if (PlayerTurn == 2) {
		i = x + 1;
		j = y - 1;
		if (isWithInIndex(i, j)) {
			if (CB[i][j].Player == 1 && CB[i][j].PieceName == 'P')
				return false;
		}
		j = y + 1;
		if (isWithInIndex(i, j)) {
			if (CB[i][j].Player == 1 && CB[i][j].PieceName == 'P')
				return false;
		}
	}

	// for plus direction checking
	for (j = y - 1; j >= 0; j--) //left+
		if (CB[x][j].Player != 0) {
			if (isPlusCheckMate(x, j, a, b))
				return false;
			break;
		}
	for (j = y + 1; j < 8; j++) // right+
		if (CB[x][j].Player != 0) {
			if (isPlusCheckMate(x, j, a, b))
				return false;
			break;
		}
	for (i = x - 1; i >= 0; i--) //up+
		if (CB[i][y].Player != 0) {
			if (isPlusCheckMate(i, y, a, b))
				return false;
			break;
		}
	for (i = x + 1; i < 8; i++) //down+
		if (CB[i][y].Player != 0) {
			if (isPlusCheckMate(i, y, a, b))
				return false;
			break;
		}
	//correct
	// for into direction checking 
	for (i = x - 1, j = y - 1; i >= 0 && j >= 0; i--, j--)//top left
		if (CB[i][j].Player != 0) {
			if (isIntoCheckMate(i, j, a, b))
				return false;
			break;
		}
	for (i = x - 1, j = y + 1; i >= 0 && j < 8; i--, j++)//top right
		if (CB[i][j].Player != 0) {
			if (isIntoCheckMate(i, j, a, b))
				return false;
			break;
		}
	for (i = x + 1, j = y + 1; i < 8 && j < 8; i++, j++) //bottom right
		if (CB[i][j].Player != 0) {
			if (isIntoCheckMate(i, j, a, b))
				return false;
			break;
		}
	for (i = x + 1, j = y - 1; i < 8 && j >= 0; i++, j--) //bottom left
		if (CB[i][j].Player != 0) {
			if (isIntoCheckMate(i, j, a, b))
				return false;
			break;
		}
	//correct upto line 100
	// for L shape checking
	for (i = x - 2; i <= x + 2; i++) {
		if (i == x) continue;
		if (i == x - 1 || i == x + 1) {
			j = y - 2;
			if (isWithInIndex(i, j) && isLShapeCheckMate(i, j, a, b))
				return false;
			j = y + 2;
			if (isWithInIndex(i, j) && isLShapeCheckMate(i, j, a, b))
				return false;
		}
		else {
			j = y - 1;
			if (isWithInIndex(i, j) && isLShapeCheckMate(i, j, a, b))
				return false;
			j = y + 1;
			if (isWithInIndex(i, j) && isLShapeCheckMate(i, j, a, b))
				return false;
		}
	}



	return true;
}
bool isCanCastling(int x1, int y1, int x2, int y2) {
	castlingIndex = (PlayerTurn == 1) ? 7 : 0;
	if (CB[castlingIndex][y1].PieceSource.h != CB[castlingIndex][y1].PieceDestination.h || CB[castlingIndex][y1].PieceSource.v != CB[castlingIndex][y1].PieceDestination.v)
		return false;
	if (y2 == 2) {
		if (CB[castlingIndex][0].PieceSource.h != CB[castlingIndex][0].PieceDestination.h || CB[castlingIndex][0].PieceSource.v != CB[castlingIndex][0].PieceDestination.v)
			return false;

		for (int j = 1; j < y1; j++)
			if (CB[castlingIndex][j].Player != 0)
				return false;
	}
	if (y2 == 6) {
		if (CB[castlingIndex][7].PieceSource.h != CB[castlingIndex][7].PieceDestination.h || CB[castlingIndex][7].PieceSource.v != CB[castlingIndex][7].PieceDestination.v)
			return false;

		for (int j = y1 + 1; j < 7; j++)
			if (CB[castlingIndex][j].Player != 0)
				return false;
	}
	return true;
}
bool CheckKing(int check, int a, int b, int c, int d) {
	if ((abs(c - a) == 0 && abs(d - b) == 1) || (abs(c - a) == 1 && abs(d - b) == 0) || (abs(c - a) == 1 && abs(d - b) == 1)) {
		if (CB[c][d].Player == 0) {
			if (!isCheckMateSafe(c, d, a, b)) {
				if (check != 1)
					printf("\nDestination was Checked !!\n");
				return false;
			}
			if (check == 1)
				return true;
			move();
			ck = 0;
			return true;
		}
		else if (CB[c][d].Player != CB[a][b].Player) {
			if (!isCheckMateSafe(c, d, a, b)) {
				if (check != 1)
					printf("\nDestination was Checked !!\n");
				return false;
			}
			if (check == 1)
				return true;
			kill();
			ck = 0;
			return true;
		}
	}
	else if (a == c && abs(d - b) == 2) {
		if (isCanCastling(a, b, c, d)) {
			if (d == 2) {
				if (isCheckMateSafe(c, d, a, b) && isCheckMateSafe(c, d + 1, a, b) && isCheckMateSafe(a, b, a, b)) {
					if (check == 1)
						return true;
					castlingMove('K', a, b, c, d); // castling move
					ck = 0;
					a = castlingIndex;
					b = 0;
					c = castlingIndex;
					d = 3;
					castlingMove('R', a, b, c, d); // castling move
					return true;
				}
				else {
					printf("\nCastling Not Possible,because Path is in Check!!\n");
					return false;
				}
			}
			if (d == 6) {
				if (isCheckMateSafe(c, d, a, b) && isCheckMateSafe(c, d - 1, a, b) && isCheckMateSafe(a, b, a, b)) {
					if (check == 1)
						return true;
					castlingMove('K', a, b, c, d); // castling move
					ck = 0;
					a = castlingIndex;
					b = 7;
					c = castlingIndex;
					d = 5;
					castlingMove('R', a, b, c, d); // castling move
					return true;
				}
				else {
					printf("\nCastling Not Possible,because Path is in Check!!\n");
					return false;
				}
			}
		}
	}
	return false;
}