void printcharacter(char piecename) {
	_setmode(_fileno(stdout), _O_U8TEXT);

	switch (piecename) {
	case 'K': wprintf(L"\x1b[%dm\u265A\x1b[0m", player_color);
		break;
	case 'Q': wprintf(L"\x1b[%dm\u265B\x1b[0m", player_color);
		break;
	case 'R': wprintf(L"\x1b[%dm\u265C\x1b[0m", player_color);
		break;
	case 'B': wprintf(L"\x1b[%dm\u265D\x1b[0m", player_color);
		break;
	case 'N': wprintf(L"\x1b[%dm\u265E\x1b[0m", player_color);
		break;
	case 'P': wprintf(L"\x1b[%dm\u2659\x1b[0m", player_color);
		break;
	}
	_setmode(_fileno(stdout), _O_TEXT);
	return;
}
void tPrintBoard() {
	printf("\nChess Board :\n");
	printf("  |        A         |        B         |        C         |        D         |        E         |        F         |        G         |        H         |\n");
	printf("  |__________________|__________________|__________________|__________________|__________________|__________________|__________________|__________________|\n");

	for (int i = 0; i < 8; i++) {
		printf("  |                  |                  |                  |                  |                  |                  |                  |                  |\n");
		printf("%d ", 8 - i);
		for (int j = 0; j < 8; j++) {
			printf("| %d %c%d (%d %d) (%d %d) ", CB[i][j].Player, CB[i][j].PieceName, CB[i][j].PieceCount, CB[i][j].PieceSource.h, CB[i][j].PieceSource.v, CB[i][j].PieceDestination.h, CB[i][j].PieceDestination.v);
		}
		printf("| %d\n", 8 - i);
		printf("  |__________________|__________________|__________________|__________________|__________________|__________________|__________________|__________________|\n");

	}
	printf("  |                  |                  |                  |                  |                  |                  |                  |                  |\n");
	printf("  |        A         |        B         |        C         |        D         |        E         |        F         |        G         |        H         |\n");
}

void sPrintBoard() {
	printf("\nChess Board :\n");
	printf("\t\t      A      B      C      D      E      F      G      H   \n");
	printf("\t\t   _______________________________________________________ \n");
	for (int i = 0; i < 8; i++) {
		printf("\t\t  |      |      |      |      |      |      |      |      |\n\t\t%d ", 8 - i);
		for (int j = 0; j < 8; j++) {
			if (CB[i][j].Player != 0)
				printf("| %d %c%d ", CB[i][j].Player, CB[i][j].PieceName, CB[i][j].PieceCount);
			else
				printf("|      ");
		}
		printf("| %d\n\t\t  |______|______|______|______|______|______|______|______|\n", 8 - i);

	}
	//printf("\t\t         |      |      |      |      |      |      |       \n");
	printf("\n\t\t      A      B      C      D      E      F      G      H   \n");
}

void UPrintBoard() {
	printf("\nChess Board :\n");
	printf("\t\t      A      B      C      D      E      F      G      H   \n");
	printf("\t\t   _______________________________________________________ \n");
	for (int i = 0; i < 8; i++) {
		printf("\t\t  |      |      |      |      |      |      |      |      |\n\t\t%d ", 8 - i);
		for (int j = 0; j < 8; j++) {
			if (CB[i][j].Player != 0)
				if (CB[i][j].Player == 1)
					printf("|   \x1b[31m%c\x1b[0m  ", CB[i][j].PieceName);
				else
					printf("|   \x1b[32m%c\x1b[0m  ", CB[i][j].PieceName);
			else
				printf("|      ");
		}
		printf("| %d\n\t\t  |______|______|______|______|______|______|______|______|\n", 8 - i);

	}
	//printf("\t\t         |      |      |      |      |      |      |       \n");
	printf("\n\t\t      A      B      C      D      E      F      G      H   \n");
}

void PrintBoard() {
	//printf("\nChess Board :\n");
	//printf("\t\t\t\t\t\t\t\t\t     A     B     C     D     E     F     G     H   \n");
	//printf("\n\n\n");
	printf("\t\t\t\t\t    A     B     C     D     E     F     G      H   \n");
	color2 = 48; // Black
	color1 = 47; // White
	for (int i = 0; i < 8; i++) {
		//printf("\t\t\t\t\t\t\t\t\t  \x1b[0m");
		printf("\t\t\t\t\t  \x1b[0m");
		for (int j = 0; j < 8; j++) {
			if ((i % 2 == 0 && j % 2 == 0) || (i % 2 != 0 && j % 2 != 0)) {
				printf("\x1b[%dm      \x1b[0m", color1);
			}
			else {
				printf("\x1b[%dm      \x1b[0m", color2);
			}
		}
		//printf("\n\t\t\t\t\t\t\t\t\t");
		printf("\n\t\t\t\t\t");
		printf("\x1b[0m%d ", 8 - i);
		for (int j = 0; j < 8; j++) {
			if ((i % 2 == 0 && j % 2 == 0) || (i % 2 != 0 && j % 2 != 0)) {
				if (CB[i][j].Player != 0) {
					player_color = (CB[i][j].Player == 1) ? 32 : 91;
					printf("\x1b[0m\x1b[%dm  ", color1);
					printcharacter(CB[i][j].PieceName);
					printf("\x1b[0m\x1b[%dm   \x1b[0m", color1);
					//printf("\x1b[0m\x1b[%dm   \x1b[%dm%c\x1b[0m\x1b[%dm  \x1b[0m", color1, player_color, printcharacter(CB[i][j].PieceName), color1);
				}
				else {
					printf("\x1b[%dm      \x1b[0m", color1);
				}
			}
			else {
				if (CB[i][j].Player != 0) {
					player_color = (CB[i][j].Player == 1) ? 32 : 91;
					printf("\x1b[0m\x1b[%dm  ", color2);
					printcharacter(CB[i][j].PieceName);
					printf("\x1b[0m\x1b[%dm   \x1b[0m", color2);
					//printf("\x1b[0m\x1b[%dm   \x1b[%dm%c\x1b[0m\x1b[%dm  \x1b[0m", color2, player_color, CB[i][j].PieceName, color2);
				}
				else {
					printf("\x1b[%dm      \x1b[0m", color2);
				}
			}
		}
		printf("\x1b[0m %d \n", 8 - i);
		//printf("\t\t\t\t\t\t\t\t\t  \x1b[0m");
		printf("\t\t\t\t\t  \x1b[0m");
		for (int j = 0; j < 8; j++) {
			if ((i % 2 == 0 && j % 2 == 0) || (i % 2 != 0 && j % 2 != 0)) {
				printf("\x1b[%dm      \x1b[0m", color1);
			}
			else {
				printf("\x1b[%dm      \x1b[0m", color2);
			}
		}
		if (i != 7)
			printf("\n");
		else
			printf("");
	}
	//printf("\x1b[0m\n\t\t\t\t\t\t\t\t\t     A     B     C     D     E     F     G     H   \n");
	printf("\x1b[0m\n\t\t\t\t\t    A     B     C     D     E     F     G      H   \n");
}
//print pieces count which are present on board
void PrintPieceCount() {
	printf("\nPieces count on Board :\n");
	printf("	   R N B Q P\n");
	for (int i = 0; i < 2; i++) {
		printf((i == 0) ? "Player 2: " : "Player 1: ");
		for (int j = 0; j < 5; j++) {
			printf(" %d", PieceCount[i][j]);
		}
		printf("\n");
	}
}

void PrintPieceStatus() {
	printf("\n");
	for (int i = 0; i < 2; i++) {
		i == 0 ? printf("Player - 2 : ") : printf("Player - 1 : ");
		for (int j = 0; j < 16; j++)
			if (Status[i][j].PiecePosition.v != -1 && Status[i][j].PiecePosition.h != -1)
				//printf("%d %d %c%d %c%d|", Status[i][j].Player, Status[i][j].isAlive, Status[i][j].PieceName, Status[i][j].PieceCount, Status[i][j].PiecePosition.v+ 65, 8 - Status[i][j].PiecePosition.h);
				printf("%d%c%d %c%d|", Status[i][j].Player, Status[i][j].PieceName, Status[i][j].PieceCount, Status[i][j].PiecePosition.v + 65, 8 - Status[i][j].PiecePosition.h);
			else
				//printf("%d %d %c%d **|", Status[i][j].Player, Status[i][j].isAlive, Status[i][j].PieceName, Status[i][j].PieceCount);
				printf("%d%c%d **|", Status[i][j].Player, Status[i][j].PieceName, Status[i][j].PieceCount);
		printf("\n");
	}
}
void printtemp() {
	printf("\n%d %c%d %d%d %d%d|", temp.Player, temp.PieceName, temp.PieceCount, temp.PieceSource.h, temp.PieceSource.v, temp.PieceDestination.h, temp.PieceDestination.v);
}
void PrintAll() {
	PrintBoard();
	//PrintPieceCount();
	//printtemp();
	//PrintPieceStatus();

}

void PrintNotation() {
	printf("\nEx:- D1D3,\tD1 -> Source Position\tD3 -> Destination Position\n");
}
void instrunctions() {
	printf("\nHere are your instructions to play the game:-\n");
	printf("\t1.Maximize your screen for better experience.\n");
	printf("\t1.It allows Uppercase letters only.\n");
	printf("\t2.Enter the input in one line only.\n");
	printf("\t2.It allows you to perform all the standard moves, capturing the pieces and special moves like Castling, En-passant also.\n");
	printf("\t3.It also notifies when the game is in Check or Checkmate or Stalemate.\n");
	printf("\t4.For moving or capturing the piece, You have to enter Ex:- D2D3,   D2 -> Source Position   D3 -> Destination Position.\n");
	printf("\t5.For both King side and Queen side castlings, You have to move the King 2 positions then Rook will move automatically move\n\t  to thecorresponding position.\n");
	printf("\t\t  Ex:- E1C1,   E1 -> King Source Position   C1 -> King Destination Position.\n");
	printf("\t6.For En-passant, You have to move the pawn diagonally one step into the empty block.\n");
	printf("\t\t  Ex:- F5G6,   F5 -> Pawn Source Position   G6 -> Pawn Destination Position.\n");
	printf("\t7.Enter # to display the instructions at any point of time either it may Player - 1 turn or Player - 2 turn.\n");
}
bool welcomenote() {
	printf("Welcome to Console Chess...!\n");
	printf("Here is your Chess Board\n");
	PrintBoard();
	instrunctions();
	printf("\nThank you for choosing this application to play...@Sanjith Ippili\n");
	printf("Enter any key to start the game..! ");
	getch();
	system("cls");
	return true;
}