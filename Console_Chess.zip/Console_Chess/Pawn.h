void Promotion() {
	(PlayerTurn == 1) ? (index = 1) : (index = 0);
	printf("\n\nYou are ready for promotion, choose your choice : ");
	printf("\n0-ROOK   1-KNIGHT    2-BISHOP    3-QUEEN");
	printf("\n\n Enter number : ");
	scanf_s("%d", &PromotionPiece);
	printf("%d", PromotionPiece);
	if (PromotionPiece < 0 || PromotionPiece> 3) Promotion();
	PieceCount[index][PromotionPiece]++;

	//update in status of pieces
	for (int j = 0; j < 16; j++) {
		if (Status[index][j].PiecePosition.h == x2 && Status[index][j].PiecePosition.v == y2) {
			Status[index][j].PieceName = PieceNames[PromotionPiece];
			Status[index][j].PieceCount = PieceCount[index][PromotionPiece];
		}
	}

	// Update in chess board
	CB[x2][y2].PieceName = PieceNames[PromotionPiece];
	CB[x2][y2].PieceCount = PieceCount[index][PromotionPiece];

}


bool Straight(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (CB[x1][y1].Player == 1) {
		if (CB[x1][y1].PieceSource.h == CB[x1][y1].PieceDestination.h && CB[x1][y1].PieceSource.v == CB[x1][y1].PieceDestination.v) {
			if ((x1 - x2 == 1 || x1 - x2 == 2) && CB[x2][y2].Player == 0 && CB[x1 - 1][y1].Player == 0) {
				tempx1 = x1;
				tempy1 = y1;
				tempx2 = x2;
				tempy2 = y2;
				if (!pin(pin_flag, check)) {
					return false;
				}
				if (check == 1)
					return true;
				move();
				//check_1();
				return true;
			}
		}
		else if (x1 - x2 == 1 && CB[x2][y2].Player == 0) {
			tempx1 = x1;
			tempy1 = y1;
			tempx2 = x2;
			tempy2 = y2;
			if (!pin(pin_flag, check)) {
				return false;
			}
			if (check == 1)
				return true;
			move();
			//check_1();
			// player 1 promotion 
			if (x2 == 0) Promotion();
			return true;
		}
	}
	else {
		if (CB[x1][y1].PieceSource.h == CB[x1][y1].PieceDestination.h && CB[x1][y1].PieceSource.v == CB[x1][y1].PieceDestination.v) {
			if ((x2 - x1 == 1 || x2 - x1 == 2) && CB[x2][y2].Player == 0 && CB[x1 + 1][y1].Player == 0) {
				tempx1 = x1;
				tempy1 = y1;
				tempx2 = x2;
				tempy2 = y2;
				if (!pin(pin_flag, check)) {
					return false;
				}
				if (check == 1)
					return true;
				move();
				//check_2();
				return true;
			}
		}
		else if (x2 - x1 == 1 && CB[x2][y2].Player == 0) {
			tempx1 = x1;
			tempy1 = y1;
			tempx2 = x2;
			tempy2 = y2;
			if (!pin(pin_flag, check)) {
				return false;
			}
			if (check == 1)
				return true;
			move();
			//check_2();
			// player 2 promotion
			if (x2 == 7) Promotion();
			return true;
		}
	}
	return false;
}

bool Diagonal(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (CB[x1][y1].Player == 1) {
		if (x1 - x2 == 1 && (y1 - y2 == 1 || y2 - y1 == 1) && CB[x2][y2].PieceName != 'K') {
			if (CB[x2][y2].Player == 2) {
				tempx1 = x1;
				tempy1 = y1;
				tempx2 = x2;
				tempy2 = y2;
				if (!pin(pin_flag, check)) {
					return false;
				}
				if (check == 1)
					return true;
				pinkill();
				kill();
				//check_1();
				// player 1 promotion 
				if (x2 == 0) Promotion();
				return true;
			}
			else if (CB[x2][y2].Player == 0 && x1 == 3) {
				if (CB[x2 + 1][y2].Player == temp.Player && CB[x2 + 1][y2].PieceName == temp.PieceName && CB[x2 + 1][y2].PieceCount == temp.PieceCount) {
					if (CB[x2 + 1][y2].PieceSource.v == CB[x2 + 1][y2].PieceDestination.v && (CB[x2 + 1][y2].PieceDestination.h - CB[x2 + 1][y2].PieceSource.h == 2)) {
						tempx1 = x1;
						tempy1 = y1;
						tempx2 = x2;
						tempy2 = y2;
						if (!pin(pin_flag, check)) {
							return false;
						}
						if (check == 1)
							return true;
						pinkill();
						EnpassantKill(x2 + 1);
						//check_1();
						return true;
					}
				}
			}
		}
	}
	if (CB[x1][y1].Player == 2) {
		if (x1 - x2 == -1 && (y1 - y2 == 1 || y2 - y1 == 1) && CB[x2][y2].PieceName != 'K') {
			if (CB[x2][y2].Player == 1) {
				tempx1 = x1;
				tempy1 = y1;
				tempx2 = x2;
				tempy2 = y2;
				if (!pin(pin_flag, check)) {
					return false;
				}
				if (check == 1)
					return true;
				pinkill();
				kill();
				//check_2();
				// player 2 promotion 
				if (x2 == 7) Promotion();
				return true;
			}
			else if (CB[x2][y2].Player == 0 && x1 == 4) {
				if (CB[x2 - 1][y2].Player == temp.Player && CB[x2 - 1][y2].PieceName == temp.PieceName && CB[x2 - 1][y2].PieceCount == temp.PieceCount) {
					if (CB[x2 - 1][y2].PieceSource.v == CB[x2 - 1][y2].PieceDestination.v && (CB[x2 - 1][y2].PieceSource.h - CB[x2 - 1][y2].PieceDestination.h == 2)) {
						tempx1 = x1;
						tempy1 = y1;
						tempx2 = x2;
						tempy2 = y2;
						if (!pin(pin_flag, check)) {
							return false;
						}
						if (check == 1)
							return true;
						pinkill();
						EnpassantKill(x2 - 1);
						//check_2();
						return true;
					}
				}
			}
		}
	}
	return false;
}


bool CheckPawn(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (y1 == y2)
		return Straight(check, pin_flag, x1, y1, x2, y2);
	else if (abs(x2 - x1) == 1)
		return Diagonal(check, pin_flag, x1, y1, x2, y2);
	return false;
}