#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<wchar.h>
#include<fcntl.h>
#include<io.h>
#include<locale.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<windows.h>
#include "Chess.h"
int main() {
	chess();
	return 0;
}