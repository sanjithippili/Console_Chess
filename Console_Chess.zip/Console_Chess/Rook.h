bool down(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	for (int i = x1 + 1; i < x2; i++)
		if (CB[i][y1].Player != 0) return false;
	if (CB[x2][y2].Player == 0) {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		move();
		return true;
	}
	else if (CB[x1][y1].Player == PlayerTurn && CB[x2][y2].Player != PlayerTurn && CB[x2][y2].PieceName != 'K') {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		pinkill();
		kill();
		return true;
	}
	return false;
}

bool up(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	for (int i = x1 - 1; i > x2; i--)
		if (CB[i][y1].Player != 0) return false;
	if (CB[x2][y2].Player == 0) {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		move();
		return true;
	}
	else if (CB[x1][y1].Player == PlayerTurn && CB[x2][y2].Player != PlayerTurn && CB[x2][y2].PieceName != 'K') {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		pinkill();
		kill();
		return true;
	}
	return false;
}

bool left(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	for (int i = y1 - 1; i > y2; i--)
		if (CB[x1][i].Player != 0) return false;
	if (CB[x2][y2].Player == 0) {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		move();
		return true;
	}
	else if (CB[x1][y1].Player == PlayerTurn && CB[x2][y2].Player != PlayerTurn && CB[x2][y2].PieceName != 'K') {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		pinkill();
		kill();
		return true;
	}
	return false;
}
bool right(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	for (int i = y1 + 1; i < y2; i++)
		if (CB[x1][i].Player != 0) return false;
	if (CB[x2][y2].Player == 0) {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		move();
		return true;
	}
	else if (CB[x1][y1].Player == PlayerTurn && CB[x2][y2].Player != PlayerTurn && CB[x2][y2].PieceName != 'K') {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		pinkill();
		kill();
		return true;
	}
	return false;
}

bool CheckRook(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (x1 == x2) {
		if (y1 > y2)  return left(check, pin_flag, x1, y1, x2, y2);
		else return right(check, pin_flag, x1, y1, x2, y2);
	}
	else if (y1 == y2) {
		if (x1 > x2) return up(check, pin_flag, x1, y1, x2, y2);
		else return down(check, pin_flag, x1, y1, x2, y2);
	}
	return false;
}