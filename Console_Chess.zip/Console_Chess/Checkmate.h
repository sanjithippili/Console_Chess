bool isKingPositionSafe(int kx, int ky) {
	int kxp, kyp;
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	kxp = Status[index][4].PiecePosition.h;
	kyp = Status[index][4].PiecePosition.v;

	//For Pawn
	if (PlayerTurn == 2) {
		if (isWithInIndex(kx - 1, ky - 1)) {
			if (CB[kxp][kyp].Player != CB[kx - 1][ky - 1].Player && CB[kx - 1][ky - 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
		if (isWithInIndex(kx - 1, ky + 1)) {
			if (CB[kxp][kyp].Player != CB[kx - 1][ky + 1].Player && CB[kx - 1][ky + 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
	}
	if (PlayerTurn == 1) {
		if (isWithInIndex(kx + 1, ky - 1)) {
			if (CB[kxp][kyp].Player != CB[kx + 1][ky - 1].Player && CB[kx + 1][ky - 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
		if (isWithInIndex(kx + 1, ky + 1)) {
			if (CB[kxp][kyp].Player != CB[kx + 1][ky + 1].Player && CB[kx + 1][ky + 1].PieceName == 'P') {
				ck = 1;
				return false;
			}
		}
	}

	//PLUS
	//Left direction 
	for (int i = ky - 1; i >= 0; i--) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[kx][i].Player != CB[kxp][kyp].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Right direction
	for (int i = ky + 1; i < 8; i++) {
		if (CB[kx][i].Player == 0) continue;
		if (CB[kx][i].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[kx][i].Player != CB[kxp][kyp].Player) {
			if (CB[kx][i].PieceName == 'R' || CB[kx][i].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Down direction 
	for (int i = kx + 1; i < 8; i++) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][ky].Player != CB[kxp][kyp].Player) {
			if ((CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q')) {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//Up direction  
	for (int i = kx - 1; i >= 0; i--) {
		if (CB[i][ky].Player == 0) continue;
		if (CB[i][ky].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][ky].Player != CB[kxp][kyp].Player) {
			if (CB[i][ky].PieceName == 'R' || CB[i][ky].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}
	//DIAGONAL
	//UP Left
	for (int i = kx - 1, j = ky - 1; i >= 0 && j >= 0; i--, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kxp][kyp].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down Right
	for (int i = kx + 1, j = ky + 1; i < 8 && j < 8; i++, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kxp][kyp].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Up Right 
	for (int i = kx - 1, j = ky + 1; i >= 0 && j < 8; i--, j++) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kxp][kyp].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//Down Left 
	for (int i = kx + 1, j = ky - 1; i < 8 && j >= 0; i++, j--) {
		if (CB[i][j].Player == 0) continue;
		if (CB[i][j].Player == CB[kxp][kyp].Player) {
			ck = 0;
			break;
		}
		if (CB[i][j].Player != CB[kxp][kyp].Player) {
			if (CB[i][j].PieceName == 'B' || CB[i][j].PieceName == 'Q') {
				ck = 1;
				return false;
			}
			else {
				ck = 0;
				break;
			}
		}
	}

	//L Direction 
	if (isWithInIndex(kx - 1, ky - 2)) {
		if (CB[kx - 1][ky - 2].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx - 1][ky - 2].Player != CB[kxp][kyp].Player && CB[kx - 1][ky - 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 1, ky + 2)) {
		if (CB[kx - 1][ky + 2].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx - 1][ky + 2].Player != CB[kxp][kyp].Player && CB[kx - 1][ky + 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky - 2)) {
		if (CB[kx + 1][ky - 2].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx + 1][ky - 2].Player != CB[kxp][kyp].Player && CB[kx + 1][ky - 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 1, ky + 2)) {
		if (CB[kx + 1][ky + 2].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx + 1][ky + 2].Player != CB[kxp][kyp].Player && CB[kx + 1][ky + 2].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky - 1)) {
		if (CB[kx - 2][ky - 1].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx - 2][ky - 1].Player != CB[kxp][kyp].Player && CB[kx - 2][ky - 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx - 2, ky + 1)) {
		if (CB[kx - 2][ky + 1].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx - 2][ky + 1].Player != CB[kxp][kyp].Player && CB[kx - 2][ky + 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky - 1)) {
		if (CB[kx + 2][ky - 1].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx + 2][ky - 1].Player != CB[kxp][kyp].Player && CB[kx + 2][ky - 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	if (isWithInIndex(kx + 2, ky + 1)) {
		if (CB[kx + 2][ky + 1].Player == CB[kxp][kyp].Player) ck = 0;
		if (CB[kx + 2][ky + 1].Player != CB[kxp][kyp].Player && CB[kx + 2][ky + 1].PieceName == 'N') {
			ck = 1;
			return false;
		}
	}
	return true;
}

bool kingsafemoves() {
	if (PlayerTurn == 1) {
		kx = Status[0][4].PiecePosition.h;
		ky = Status[0][4].PiecePosition.v;
	}
	else {
		kx = Status[1][4].PiecePosition.h;
		ky = Status[1][4].PiecePosition.v;
	}
	//top row of king
	if (isWithInIndex(kx - 1, ky - 1)) {
		if (CB[kx][ky].Player != CB[kx - 1][ky - 1].Player && isKingPositionSafe(kx - 1, ky - 1)) return true; // need to write in other if's
	}
	if (isWithInIndex(kx - 1, ky)) {
		if (CB[kx][ky].Player != CB[kx - 1][ky].Player && isKingPositionSafe(kx - 1, ky)) return true;
	}
	if (isWithInIndex(kx - 1, ky + 1)) {
		if (CB[kx][ky].Player != CB[kx - 1][ky + 1].Player && isKingPositionSafe(kx - 1, ky + 1)) return true;
	}
	//same row of king
	if (isWithInIndex(kx, ky - 1)) {
		if (CB[kx][ky].Player != CB[kx][ky - 1].Player && isKingPositionSafe(kx, ky - 1)) return true;
	}
	if (isWithInIndex(kx, ky + 1)) {
		if (CB[kx][ky].Player != CB[kx][ky + 1].Player && isKingPositionSafe(kx, ky + 1)) return true;
	}
	//bottom row
	if (isWithInIndex(kx + 1, ky - 1)) {
		if (CB[kx][ky].Player != CB[kx + 1][ky - 1].Player && isKingPositionSafe(kx + 1, ky - 1)) return true;
	}
	if (isWithInIndex(kx + 1, ky)) {
		if (CB[kx][ky].Player != CB[kx + 1][ky].Player && isKingPositionSafe(kx + 1, ky)) return true;
	}
	if (isWithInIndex(kx + 1, ky + 1)) {
		if (CB[kx][ky].Player != CB[kx + 1][ky + 1].Player && isKingPositionSafe(kx + 1, ky + 1)) return true;
	}
	return false;
}

bool captureAP() {
	int cx = temp.PieceDestination.h;
	int cy = temp.PieceDestination.v;
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName != 'K' && Status[index][i].isAlive == true) {
			switch (Status[index][i].PieceName) {
			case 'P':if (CheckPawn(1, 0, Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v, cx, cy)) return true;
				break;
			case 'B':if (CheckBishop(1, 0, Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v, cx, cy)) return true;
				break;
			case 'N':if (CheckKnight(1, 0, Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v, cx, cy)) return true;
				break;
			case 'R':if (CheckRook(1, 0, Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v, cx, cy)) return true;
				break;
			case 'Q':if (CheckQueen(1, 0, Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v, cx, cy)) return true;
				break;
			}
		}
	}
	return false;
}

void CopyValues(int x1, int y1, int x2, int y2) {
	CB[x2][y2].Player = CB[x1][y1].Player;
	CB[x2][y2].PieceName = CB[x1][y1].PieceName;
	CB[x2][y2].PieceCount = CB[x1][y1].PieceCount;
	CB[x2][y2].PieceSource.h = CB[x1][y1].PieceDestination.h;
	CB[x2][y2].PieceSource.v = CB[x1][y1].PieceDestination.v;
	CB[x2][y2].PieceDestination.h = x2;
	CB[x2][y2].PieceDestination.v = y2;
}

void setDefaultValues(int x, int y) {
	CB[x][y].Player = 0;
	CB[x][y].PieceName = ' ';
	CB[x][y].PieceCount = 0;
	CB[x][y].PieceSource.h = 0;
	CB[x][y].PieceSource.v = 0;
	CB[x][y].PieceDestination.h = 0;
	CB[x][y].PieceDestination.v = 0;
}

bool RookBlock(int rx, int ry) {
	/*int kxp, kyp;
	(PlayerTurn == 1) ? (index = 0) : (index = 1);
	kxp = Status[index][4].PiecePosition.h;
	kyp = Status[index][4].PiecePosition.v;*/
	//PLUS
	//Left direction 
	for (int i = ry - 1; i >= 0; i--) {
		if (CB[rx][i].Player == 0) {
			CopyValues(rx, ry, rx, i);
			setDefaultValues(rx, ry);
			if (!CAD()) {
				CopyValues(rx, i, rx, ry);
				setDefaultValues(rx, i);
			}
			else {
				CopyValues(rx, i, rx, ry);
				setDefaultValues(rx, i);
				return true;
			}
		}
		else {
			break;
		}
	}
	//Right direction 
	for (int i = ry + 1; i < 8; i++) {
		if (CB[rx][i].Player == 0) {
			CopyValues(rx, ry, rx, i);
			setDefaultValues(rx, ry);
			if (!CAD()) {
				CopyValues(rx, i, rx, ry);
				setDefaultValues(rx, i);
			}
			else {
				CopyValues(rx, i, rx, ry);
				setDefaultValues(rx, i);
				return true;
			}
		}
		else {
			break;
		}
	}
	//Down direction 
	for (int i = rx + 1; i < 8; i++) {
		if (CB[i][ry].Player == 0) {
			CopyValues(rx, ry, i, ry);
			setDefaultValues(rx, ry);
			if (!CAD()) {
				CopyValues(i, ry, rx, ry);
				setDefaultValues(i, ry);
			}
			else {
				CopyValues(i, ry, rx, ry);
				setDefaultValues(i, ry);
				return true;
			}
		}
		else {
			break;
		}
	}
	//up direction 
	for (int i = rx - 1; i >= 0; i--) {
		if (CB[i][ry].Player == 0) {
			CopyValues(rx, ry, i, ry);
			setDefaultValues(rx, ry);
			if (!CAD()) {
				CopyValues(i, ry, rx, ry);
				setDefaultValues(i, ry);
			}
			else {
				CopyValues(i, ry, rx, ry);
				setDefaultValues(i, ry);
				return true;
			}
		}
		else {
			break;
		}
	}
	return false;
}

bool BishopBlock(int bx, int by) {
	//DIAGONAL
	//UP Left
	for (int i = bx - 1, j = by - 1; i >= 0 && j >= 0; i--, j--) {
		if (CB[i][j].Player == 0) {
			CopyValues(bx, by, i, j);
			setDefaultValues(bx, by);
			if (!CAD()) {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
			}
			else {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
				return true;
			}
		}
		else {
			break;
		}
	}
	//Down Right
	for (int i = bx + 1, j = by + 1; i < 8 && j < 8; i++, j++) {
		if (CB[i][j].Player == 0) {
			CopyValues(bx, by, i, j);
			setDefaultValues(bx, by);
			if (!CAD()) {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
			}
			else {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
				return true;
			}
		}
		else {
			break;
		}
	}
	//Up Right
	for (int i = bx - 1, j = by + 1; i >= 0 && j < 8; i--, j++) {
		if (CB[i][j].Player == 0) {
			CopyValues(bx, by, i, j);
			setDefaultValues(bx, by);
			if (!CAD()) {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
			}
			else {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
				return true;
			}
		}
		else {
			break;
		}
	}
	//Down Left
	for (int i = bx + 1, j = by - 1; i < 8 && j >= 0; i++, j--) {
		if (CB[i][j].Player == 0) {
			CopyValues(bx, by, i, j);
			setDefaultValues(bx, by);
			if (!CAD()) {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
			}
			else {
				CopyValues(i, j, bx, by);
				setDefaultValues(i, j);
				return true; // blocking
			}
		}
		else {
			break;
		}
	}
	return false; // not blocking
}

bool QueenBlock(int qx, int qy) {
	if (RookBlock(qx, qy) || BishopBlock(qx, qy))  return true;
	return false;
}

bool KnightBlock(int nx, int ny) {
	//L Direction 1
	if (isWithInIndex(nx - 1, ny - 2)) {
		if (CB[nx - 1][ny - 2].Player == 0) {
			CopyValues(nx, ny, nx - 1, ny - 2);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx - 1, ny - 2, nx, ny);
				setDefaultValues(nx - 1, ny - 2);
			}
			else {
				CopyValues(nx - 1, ny - 2, nx, ny);
				setDefaultValues(nx - 1, ny - 2);
				return true; // blocking
			}
		}
	}
	//2
	if (isWithInIndex(nx - 1, ny + 2)) {
		if (CB[nx - 1][ny + 2].Player == 0) {
			CopyValues(nx, ny, nx - 1, ny + 2);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx - 1, ny + 2, nx, ny);
				setDefaultValues(nx - 1, ny + 2);
			}
			else {
				CopyValues(nx - 1, ny + 2, nx, ny);
				setDefaultValues(nx - 1, ny + 2);
				return true; // blocking
			}
		}
	}
	//3
	if (isWithInIndex(nx + 1, ny - 2)) {
		if (CB[nx + 1][ny - 2].Player == 0) {
			CopyValues(nx, ny, nx + 1, ny - 2);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx + 1, ny - 2, nx, ny);
				setDefaultValues(nx + 1, ny - 2);
			}
			else {
				CopyValues(nx + 1, ny - 2, nx, ny);
				setDefaultValues(nx + 1, ny - 2);
				return true; // blocking
			}
		}
	}
	//4
	if (isWithInIndex(nx + 1, ny + 2)) {
		if (CB[nx + 1][ny + 2].Player == 0) {
			CopyValues(nx, ny, nx + 1, ny + 2);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx + 1, ny + 2, nx, ny);
				setDefaultValues(nx + 1, ny + 2);
			}
			else {
				CopyValues(nx + 1, ny + 2, nx, ny);
				setDefaultValues(nx + 1, ny + 2);
				return true; // blocking
			}
		}
	}
	//5
	if (isWithInIndex(nx - 2, ny - 1)) {
		if (CB[nx - 2][ny - 1].Player == 0) {
			CopyValues(nx, ny, nx - 2, ny - 1);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx - 2, ny - 1, nx, ny);
				setDefaultValues(nx - 2, ny - 1);
			}
			else {
				CopyValues(nx - 2, ny - 1, nx, ny);
				setDefaultValues(nx - 2, ny - 1);
				return true; // blocking
			}
		}
	}
	//6
	if (isWithInIndex(nx - 2, ny + 1)) {
		if (CB[nx - 2][ny + 1].Player == 0) {
			CopyValues(nx, ny, nx - 2, ny + 1);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx - 2, ny + 1, nx, ny);
				setDefaultValues(nx - 2, ny + 1);
			}
			else {
				CopyValues(nx - 2, ny + 1, nx, ny);
				setDefaultValues(nx - 2, ny + 1);
				return true; // blocking
			}
		}
	}
	//7
	if (isWithInIndex(nx + 2, ny - 1)) {
		if (CB[nx + 2][ny - 1].Player == 0) {
			CopyValues(nx, ny, nx + 2, ny - 1);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx + 2, ny - 1, nx, ny);
				setDefaultValues(nx + 2, ny - 1);
			}
			else {
				CopyValues(nx + 2, ny - 1, nx, ny);
				setDefaultValues(nx + 2, ny - 1);
				return true; // blocking
			}
		}
	}
	//8
	if (isWithInIndex(nx + 2, ny + 1)) {
		if (CB[nx + 2][ny + 1].Player == 0) {
			CopyValues(nx, ny, nx + 2, ny + 1);
			setDefaultValues(nx, ny);
			if (!CAD()) {
				CopyValues(nx + 2, ny + 1, nx, ny);
				setDefaultValues(nx + 2, ny + 1);
			}
			else {
				CopyValues(nx + 2, ny + 1, nx, ny);
				setDefaultValues(nx + 2, ny + 1);
				return true; // blocking
			}
		}
	}
	return false;
}

bool PawnBlock(int px, int py) {
	if (CB[px][py].Player == 1) {
		if (CB[px][py].PieceSource.h == CB[px][py].PieceDestination.h && CB[px][py].PieceSource.v == CB[px][py].PieceDestination.v) {
			if (CB[px - 1][py].Player == 0 && CB[px - 2][py].Player == 0) {
				CopyValues(px, py, px - 2, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px - 2, py, px, py);
					setDefaultValues(px - 2, py);
				}
				else {
					CopyValues(px - 2, py, px, py);
					setDefaultValues(px - 2, py);
					return true; // blocking
				}
			}
			if (CB[px - 1][py].Player == 0) {
				CopyValues(px, py, px - 1, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px - 1, py, px, py);
					setDefaultValues(px - 1, py);
					return false; // to be removed 
				}
				else {
					CopyValues(px - 1, py, px, py);
					setDefaultValues(px - 1, py);
					return true; // blocking
				}
			}
		}
		if (CB[px][py].PieceSource.h != CB[px][py].PieceDestination.h && CB[px][py].PieceSource.v != CB[px][py].PieceDestination.v) {
			if (CB[px - 1][py].Player == 0) {
				CopyValues(px, py, px - 1, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px - 1, py, px, py);
					setDefaultValues(px - 1, py);
				}
				else {
					CopyValues(px - 1, py, px, py);
					setDefaultValues(px - 1, py);
					return true; // blocking
				}
			}
		}
	}
	else if (CB[px][py].Player == 2) {
		if (CB[px][py].PieceSource.h == CB[px][py].PieceDestination.h && CB[px][py].PieceSource.v == CB[px][py].PieceDestination.v) {
			if (CB[px + 1][py].Player == 0 && CB[px + 2][py].Player == 0) {
				CopyValues(px, py, px + 2, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px + 2, py, px, py);
					setDefaultValues(px + 2, py);
				}
				else {
					CopyValues(px + 2, py, px, py);
					setDefaultValues(px + 2, py);
					return true; // blocking
				}
			}
			if (CB[px + 1][py].Player == 0) {
				CopyValues(px, py, px + 1, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px + 1, py, px, py);
					setDefaultValues(px + 1, py);
					return false; //to be removed 
				}
				else {
					CopyValues(px + 1, py, px, py);
					setDefaultValues(px + 1, py);
					return true; // blocking
				}
			}
		}
		if (CB[px][py].PieceSource.h != CB[px][py].PieceDestination.h && CB[px][py].PieceSource.v != CB[px][py].PieceDestination.v) {
			if (CB[px + 1][py].Player == 0) {
				CopyValues(px, py, px + 1, py);
				setDefaultValues(px, py);
				if (!CAD()) {
					CopyValues(px + 1, py, px, py);
					setDefaultValues(px + 1, py);
				}
				else {
					CopyValues(px + 1, py, px, py);
					setDefaultValues(px + 1, py);
					return true; // blocking
				}
			}
		}
	}
	return false;
}

bool block() {
	(PlayerTurn == 1) ? (index = 0) : (index = 1); // '0' for player - 2 and '1' for player - 1
	for (int i = 0; i < 16; i++) {
		if (Status[index][i].PieceName != 'K' && Status[index][i].isAlive == true) {
			switch (Status[index][i].PieceName) {
			case 'R': if (RookBlock(Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v)) return true;
				break;
			case 'B': if (BishopBlock(Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v)) return true;
				break;
			case 'N': if (KnightBlock(Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v)) return true;
				break;
			case 'Q': if (QueenBlock(Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v)) return true;
				break;
			case 'P': if (PawnBlock(Status[index][i].PiecePosition.h, Status[index][i].PiecePosition.v)) return true;
				break;
			}
		}
	}
	return false;
}

bool checkmate() {
	if (kingsafemoves()) return false;//for safe moves
	else {//capture
		if (captureAP()) return false;
		else {//block
			if (temp.PieceName == 'N' && temp.Player == PlayerTurn) return true;
			else {
				if (block()) {
					return false;
				}
				else {
					return true;
				}
			}
		}
	}
	return true;
}