bool isDiagonal(int x1, int y1, int x2, int y2) {
	if (abs(x1 - x2) == abs(y1 - y2))
		return true;
	return false;
}

bool isDiagonalPathFree(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	int i = x1, j = y1;
	// for center top to right side down direction diagonal 
	if (i < x2 && j < y2) {
		i++; j++;
		while (i < x2 && j < y2) {
			if (CB[i][j].Player != 0)
				return false;
			i++; j++;
		}
	}
	// for  center bottom to left side up direction diagonal 
	else if (i > x2 && j > y2) {
		i--; j--;
		while (i > x2 && j > y2) {
			if (CB[i][j].Player != 0)
				return false;
			i--; j--;
		}
	}
	// for center bottom to right side up direction diagonal 
	else if (i > x2 && j < y2) {
		i--; j++;
		while (i > x2 && j < y2) {
			if (CB[i][j].Player != 0)
				return false;
			i--; j++;
		}
	}
	else {
		i++; j--;
		while (i < x2 && j > y2) {
			if (CB[i][j].Player != 0)
				return false;
			i++; j--;
		}
	}
	if (CB[x2][y2].Player == 0) {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		move();
		ck = 0;
		return true;
	}
	if (CB[x2][y2].Player != CB[x1][y1].Player && CB[x2][y2].PieceName != 'K') {
		tempx1 = x1;
		tempy1 = y1;
		tempx2 = x2;
		tempy2 = y2;
		if (!pin(pin_flag, check)) {
			return false;
		}
		if (check == 1)
			return true;
		pinkill();
		kill();
		ck = 0;
		return true;
	}
	return false;
}

bool CheckBishop(int check, int pin_flag, int x1, int y1, int x2, int y2) {
	if (isDiagonal(x1, y1, x2, y2))
		return isDiagonalPathFree(check, pin_flag, x1, y1, x2, y2);
	return false;
}